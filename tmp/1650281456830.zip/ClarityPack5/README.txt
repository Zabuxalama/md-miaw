
>Thank For Downloading ClarityPack V.5

>Subscribe Me On Youtube : BlasterMC

Support Mcpe/Mcbe 1.17.0 - 1.17.10

>|INFORMATIONS|<

Texture ClarityPack V.5 by BlasterMC
BlasterMC = Old ClarityDiamond

I made this texture for the first time from clarity pack v.1
you can see it on my channel (BlasterMC)

this is just a Modification texture by combining textures from various mcpe/mcpc textures

>>in this texture all items/blocks & others have been changed, because I have checked (1 by 1) the item/block :v <<

thank you very much for downloading this texture :D

if there are shortcomings or bugs please contact [claritydiamond75@gmail.com]

if you want to showcase please give the credit.

>|ATTENTION|<
this is just a modification texture. Anyone can modify this texture again, and if you don't mind, you can add credit (like the creator's channel = blastermc :D )

it is forbidden to take the texture completely and only change the icon/texture name

>|CREDIT - BIG THANKS TO)

»Steven's Traditional - 5teven
»Multipixel - Zou Chenyunfei
»Minecraft HD 64 - Mrdhobbs
»EnderDrago - MWCubed
»Java Aspect (Sound) - AgentMindStrom
»No Red Arrow - Mhavin
»Realistic P - ArcStudios05
»ClarityPack V.3
»ClarityPack V.4
»MM Shaders 3 - Monoflex
»Compliance 64× - harag0nmc

>>Thanks For Reading This<<
